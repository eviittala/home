import random

class AiCpuPoints:
    def __init__(self, maxScreenSizeX, maxScreenSizeY, cellSize):
        self.maxScreenSizeX = maxScreenSizeX
        self.maxScreenSizeY = maxScreenSizeY
        self.cellSize = cellSize
        self.cellOffset = cellSize + 1  # +1 since border is size of one
        self.cpuPoints = []
        self.offsets = {0 : [self.cellOffset, 0], 1 : [self.cellOffset, self.cellOffset], 2 : [0, self.cellOffset], 3 : [-(self.cellOffset), self.cellOffset], 
                        4 : [-(self.cellOffset), 0], 5 : [-(self.cellOffset), -(self.cellOffset)], 6 : [0, -(self.cellOffset)], 7 : [self.cellOffset, -(self.cellOffset)] }

    def getMaxScreenSizeX(self):
        return self.maxScreenSizeX

    def getMaxScreenSizeY(self):
        return self.maxScreenSizeY

    def getCellSize(self):
        return self.cellSize

    def sortBasedOnHits(self, myList):
        return myList[2]

    def printValues(self):
        print("playerPoints:")
        print(self.playerPoints)
        print("cpuPoints:")
        print(self.cpuPoints)

    def setPlayerPoints(self, playerPoints):
        """Fill player points, List[XY, direction, hits] """
        self.playerPoints = playerPoints
        if len(self.playerPoints) > 1:
            self.playerPoints.sort(key = self.sortBasedOnHits, reverse = True)

    def getPlayerPoints(self):
        return self.playerPoints

    def setCpuPoints(self, cpuPoints):
        """Fill cpu points, List[XY, direction, hits] """
        self.cpuPoints = cpuPoints
        if len(self.cpuPoints):
            self.cpuPoints.sort(key = self.sortBasedOnHits, reverse = True)

    def getCpuPoints(self):
        return self.cpuPoints

    def isXYHittingPoints(self, XY, points):
        """ Returns True, if XY is in points """
        for point in points:
            offset = self.offsets[point[1]]
            hits = point[2]
            for i in range(hits):
                x = point[0][0] + offset[0] * i
                y = point[0][1] + offset[1] * i
                #print("XY: {0} point: {1} {2} {3}". format(XY, point[0], x, y))
                if XY[0] == x and XY[1] == y:
                    return True
        return False            

    def isValidPosition(self, XY):
        if self.isXYHittingPoints(XY, self.playerPoints):
            return False
        if self.isXYHittingPoints(XY, self.cpuPoints):
            return False
        return XY[0] > 0 and XY[0] < self.maxScreenSizeX and XY[1] > 0 and XY[1] < self.maxScreenSizeY

    def getEndXY(self, point):
        offset = self.offsets[point[1]]
        hits = point[2] - 1
        return [point[0][0] + offset[0] * hits, point[0][1] + offset[1] * hits]

    def getLeftXY(self, point):
        direction = point[1]
        coffset = self.offsets[direction + 4]
        return [point[0][0] + coffset[0], point[0][1] + coffset[1]]

    def getRightXY(self, point):
        direction = point[1]
        hits = point[2]
        offset = self.offsets[direction]
        return [point[0][0] + offset[0] * hits, point[0][1] + offset[1] * hits]

    def getNextXY(self, XY, direction):
        offset = self.offsets[direction]
        return [XY[0] + offset[0], XY[1] + offset[1]]

    def countCpuHitsForThisPoint(self, point):
        """ Count Cpu hits if this point will be used"""
        retHits = 0
        for offsetDir, offsetXY in self.offsets.items():
            XY = self.getNextXY(point, offsetDir)
            for cpuPoint in self.cpuPoints:
                countHits = 0
                if self.isXYHittingPoints(XY, [cpuPoint]):
                    if cpuPoint[2] == 1 or cpuPoint[1] != offsetDir:
                        countHits = 1
                    else:
                        countHits = cpuPoint[2] + 1

                    if countHits > retHits:
                        retHits = countHits
        return retHits

    def determinePoints(self, points):
        """ Returns best point """
        idx = 0
        maxHits = -1
        #print("determinePoints len:{0}".format(len(points)))
        for i in range(len(points)):
            if self.isValidPosition(points[i]):
                hits = self.countCpuHitsForThisPoint(points[i])
                #print("Hits: {0} masHits {1} point({2})".format(hits, maxHits, points[i]))
                if hits > maxHits:
                    #print("Hits: {0} point({1})".format(hits, points[i]))
                    maxHits = hits
                    idx = i

        return points[idx]

    def getBestIdx(self, points):
        """ Returns idx of the points, which have the best possible change to win """
        # TODO Eero:
        retIdx = 0xffff
        retHits = 0
        for idx in range(len(points)):
            hits = points[idx][2]
            direction = points[idx][1]
            leftXY = self.getLeftXY(points[idx])
            rightXY = self.getRightXY(points[idx])
            possibleHits = 0
            ownHits = 0
            for i in range(5 - hits):
                if self.isXYHittingPoints(leftXY, points):
                    possibleHits += 1
                    ownHits += 1
                    leftXY = self.getNextXY(leftXY, direction + 4)
                elif self.isValidPosition(leftXY):
                    #print("leftValid {0}". format(leftXY))
                    possibleHits += 1
                    leftXY = self.getNextXY(leftXY, direction + 4)
                if self.isXYHittingPoints(rightXY, points):
                    possibleHits += 1
                    ownHits += 1
                    rightXY = self.getNextXY(rightXY, direction)
                elif self.isValidPosition(rightXY):
                    #print("rightValid {0}". format(rightXY))
                    possibleHits += 1
                    rightXY = self.getNextXY(rightXY, direction)
                if possibleHits + hits >= 5:
                    if ownHits + hits > retHits:
                        # print("idx: {0} possibleHits {1} ownHits: {2} hits: {3}".format(idx, possibleHits, ownHits, hits))
                        retIdx = idx
                        retHits = ownHits + hits
                        
        return retIdx            

    def arrangePoints(self, points, idx):
        """ Arrange points, idx will be first """
        if idx != 0:
            copyList = points.copy()
            points.clear()
            for point in copyList[idx:]:
                points.append(point)
            for point in copyList[0:idx]:
                points.append(point)

                
    def getTurnNumber(self):
        """ Return 0, if playerPoints needs to be covered, first playerPoints have the most dangerous point
            Return 1, if cpu has better chance to win, first cpuPoints have the best choice to use"""
        invalidIdx = 0xffff    
        bestPlayerIdx = self.getBestIdx(self.playerPoints)
        bestCpuIdx = self.getBestIdx(self.cpuPoints)

        print("bestPlayerIdx: {0} bestCpuIdx: {1}".format(bestPlayerIdx, bestCpuIdx))
        self.printValues()

        if bestPlayerIdx != invalidIdx and bestCpuIdx == invalidIdx:
            self.arrangePoints(self.playerPoints, bestPlayerIdx)
            return 0
        if bestPlayerIdx == invalidIdx and bestCpuIdx != invalidIdx:
            self.arrangePoints(self.cpuPoints, bestCpuIdx)
            return 1
        if self.playerPoints[bestPlayerIdx][2] > self.cpuPoints[bestCpuIdx][2]:
            self.arrangePoints(self.playerPoints, bestPlayerIdx)
            return 0
        self.arrangePoints(self.cpuPoints, bestCpuIdx)
        print("bestCpuIdx: {0} bestPlayerIdx: {1}".format(bestCpuIdx, bestPlayerIdx))
        self.printValues()
        return 1

    def getRandomPointForXY(self, XY):
        randDir = random.randrange(0, 8)
        retXY = self.getNextXY(XY, randDir)
        while not self.isValidPosition(retXY):
            randDir = random.randrange(0, 8)
            retXY = self.getNextXY(XY, randDir)
        return retXY

    def getCpuPoint(self):
        """ Returns XY """
        if len(self.playerPoints) == 1 and len(self.cpuPoints) == 0: # First move
            return self.getRandomPointForXY(self.playerPoints[0][0])
        else:
            whosTurn = self.getTurnNumber()
            print("whosTurn : {0}".format(whosTurn))
            if whosTurn == 0:
                hits = self.playerPoints[0][2]
                direction = self.playerPoints[0][1]
                offset = self.offsets[direction]
                cOffset = self.offsets[direction + 4]
                points = []
                points.append([self.playerPoints[0][0][0] + offset[0] * hits, self.playerPoints[0][0][1] + offset[1] * hits])
                points.append([self.playerPoints[0][0][0] + cOffset[0], self.playerPoints[0][0][1] + cOffset[1]])
                return self.determinePoints(points)
            
            hits = self.cpuPoints[0][2]
            if hits == 1:
                return self.getRandomPointForXY(self.cpuPoints[0][0])
            direction = self.cpuPoints[0][1]
            offset = self.offsets[direction]
            cOffset = self.offsets[direction + 4]
            points = []
            points.append([self.cpuPoints[0][0][0] + offset[0] * hits, self.cpuPoints[0][0][1] + offset[1] * hits])
            points.append([self.cpuPoints[0][0][0] + cOffset[0], self.cpuPoints[0][0][1] + cOffset[1]])
            return self.determinePoints(points)
            
