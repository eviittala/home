#!/usr/bin/python

import sys, pygame, random, AiCpuPoints 
from pygame.locals import *

WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GRAY = (220, 220, 220)
CELL_SIZE = 20
CELL_OFFSET = CELL_SIZE + 1
MAX_SCREEN_SIZE_X = (CELL_OFFSET) * 50 - 1
MAX_SCREEN_SIZE_Y = (CELL_OFFSET) * 50 - 1
HOOVER = [[5, 5]]
OFFSETS = {0 : [CELL_OFFSET, 0], 1 : [CELL_OFFSET, CELL_OFFSET], 2 : [0, CELL_OFFSET], 3 : [-(CELL_OFFSET), CELL_OFFSET]}
COUNTEROFFSETS = {0 : [-(CELL_OFFSET), 0], 1 : [-(CELL_OFFSET), -(CELL_OFFSET)], 2 : [0, -(CELL_OFFSET)], 3 : [CELL_OFFSET, -(CELL_OFFSET)]}
aiCpuPoints = AiCpuPoints.AiCpuPoints(MAX_SCREEN_SIZE_X, MAX_SCREEN_SIZE_Y, CELL_SIZE)

def getBlockPos(mousePos):
    ret = [0, 0]

    for posX in range (CELL_SIZE, MAX_SCREEN_SIZE_X + 1, CELL_OFFSET):
        if mousePos[0] < posX:
            ret[0] = posX - CELL_SIZE / 2
            break
    for posY in range (CELL_SIZE, MAX_SCREEN_SIZE_Y + 1, CELL_OFFSET):
        if mousePos[1] < posY:
            ret[1] = posY - CELL_SIZE / 2
            break

    return ret;        

class Hoover(pygame.sprite.Sprite):
    """Hoover"""

    def __init__(self, size):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface([size, size])
        self.image.fill(GRAY)
        self.rect = self.image.get_rect()
        self.area = screen.get_rect()

    def update(self):
        mousePos = pygame.mouse.get_pos()
        self.rect.center = getBlockPos(mousePos)
        
class Player(pygame.sprite.Sprite):
    """Player"""

    def __init__(self, size, x, y, color):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface([size, size])
        self.image.fill(color)
        self.rect = self.image.get_rect()
        self.area = screen.get_rect()
        self.rect.center = [x, y]

    def update(self):
        pass

    def getXY(self):
        return [self.rect.center[0], self.rect.center[1]]
        
def isValidXY(x, y):
    if not (0 < x and 0 < y and x < MAX_SCREEN_SIZE_X and y < MAX_SCREEN_SIZE_Y):
        return False
    for sprite in [playerSprite, cpuSprite]: 
        if pygame.sprite.spritecollide(Player(CELL_SIZE - 4, x, y, WHITE), sprite, False):
            return False
    return True

def countHits(XYlist, XYOffsetList, hits, sprite):
    if pygame.sprite.spritecollide(Player(CELL_SIZE - 4, XYlist[0], XYlist[1], WHITE), sprite, False):
        return countHits([XYlist[0] + XYOffsetList[0], XYlist[1] + XYOffsetList[1]], XYOffsetList, hits + 1, sprite)
    else:
        return hits

def myListSorter(myList):
    return myList[2]

def isCoveredByOtherLeft(XY, direction, sprite):
    x = XY[0] + COUNTEROFFSETS[direction][0]
    y = XY[1] + COUNTEROFFSETS[direction][1]
    return pygame.sprite.spritecollide(Player(CELL_SIZE - 4, x, y, WHITE), sprite, False)

def isCoveredByOtherRight(XY, direction, hits, sprite):
    x = XY[0] + OFFSETS[direction][0] * hits
    y = XY[1] + OFFSETS[direction][1] * hits
    return pygame.sprite.spritecollide(Player(CELL_SIZE - 4, x, y, WHITE), sprite, False)

def getHits(XY, direction, ownSprite):
    hits = countHits(XY.copy(), OFFSETS[direction], 0, ownSprite)
    cOffset = COUNTEROFFSETS[direction]
    counterHits = countHits([XY[0] + cOffset[0], XY[1] + cOffset[1]], cOffset, 0, ownSprite)
    if counterHits == 0:
        return hits
    return 0

def fillPoints(ownSprites, listToFill):
    ownSpriteList = pygame.sprite.Group(ownSprites).sprites()

    for ownSprite in ownSpriteList:
        XY = ownSprite.getXY();
        for direction in range(4):
            hits = getHits(XY.copy(), direction, ownSprites)
            if hits > 0 and (hits != 1 or direction == 0):
                listToFill.append([XY, direction, hits])

def getLeftX(point):
    idx = point[1]
    cOffset = COUNTEROFFSETS[idx]
    return point[0][0] + cOffset[0]

def getLeftY(point):
    idx = point[1]
    cOffset = COUNTEROFFSETS[idx]
    return point[0][1] + cOffset[1]

def getRightX(point):
    idx = point[1]
    offset = OFFSETS[idx]
    return point[0][0] + offset[0] * point[0][2]

def getRightY(point):
    idx = point[1]
    offset = OFFSETS[idx]
    return point[0][1] + offset[1] * point[0][2]

def getGapPoint(topPlayerGapPoints, topCpuGapPoints):
    """ Return XY, returns empty list if no point found """
    if len(topPlayerGapPoints) and topPlayerGapPoints[0][2] > 2:
        return topPlayerGapPoints[0][0]
    elif len(topCpuGapPoints) and topCpuGapPoints[0][2] > 2:
        return topCpuGapPoints[0][0]
    else:
        return []

def printValues():
    print("PlayerPoints:")
    print(aiCpuPoints.getPlayerPoints())
    print("CpuPoints:")
    print(aiCpuPoints.getCpuPoints())

def determineCpuCell():
    playerPoints = []
    cpuPoints = []

    fillPoints(playerSprite, playerPoints)
    fillPoints(cpuSprite, cpuPoints)

    aiCpuPoints.setPlayerPoints(playerPoints)
    aiCpuPoints.setCpuPoints(cpuPoints)
    #printValues()
    XY = aiCpuPoints.getCpuPoint()
    print("CPU point: {0}".format(XY))
    return XY

def getWinner():
    playerList = pygame.sprite.Group(playerSprite).sprites()
    cpuList = pygame.sprite.Group(cpuSprite).sprites()

    for pList in playerList:
        XY = pList.getXY();
        for direction in range(4):
            hits = countHits(XY.copy(), OFFSETS[direction], 0, playerSprite)
            if hits == 5:
                printValues()
                return 1

    for cList in cpuList:
        XY = cList.getXY();
        for direction in range(4):
            hits = countHits(XY.copy(), OFFSETS[direction], 0, cpuSprite)
            if  hits == 5:
                printValues()
                return 2
    return 0    

def main():
    pygame.init()
    global screen
    global playerSprite
    global cpuSprite
    screen = pygame.display.set_mode((MAX_SCREEN_SIZE_X, MAX_SCREEN_SIZE_Y))
    pygame.display.set_caption('Eeros TicTacToe')
    screen.fill(WHITE)
    hoover = Hoover(CELL_SIZE)
    cpu = Player(CELL_SIZE - 4, 31, 31, BLACK)
    hooverSprite = pygame.sprite.RenderPlain((hoover))
    playerSprite = pygame.sprite.Group()
    cpuSprite = pygame.sprite.Group()
    background = pygame.Surface(screen.get_size())
    background = background.convert()
    background.fill(WHITE)
    for pos in range (CELL_SIZE, MAX_SCREEN_SIZE_X, CELL_OFFSET):
        pygame.draw.line(background, BLACK, [0, pos], [MAX_SCREEN_SIZE_X, pos], 1)
        pygame.draw.line(background, BLACK, [pos, 0], [pos, MAX_SCREEN_SIZE_Y], 1)
    screen.blit(background, (0, 0))

    pygame.display.flip()

    winner = 0
    playerUpdated = False
    printMousePos = [0, 0]
    textToPrint = ""
    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                return
            if event.type == MOUSEMOTION:
                printMousePos = pygame.mouse.get_pos()
            if event.type == MOUSEBUTTONDOWN:    
                mousePos = pygame.mouse.get_pos()
                block = getBlockPos(mousePos)
#                player = Player(CELL_SIZE - 4, block[0], block[1], RED)
#                playerHits = pygame.sprite.spritecollide(player, playerSprite, False)
                if isValidXY(block[0], block[1]) and winner == 0:
                    playerUpdated = True
                    pygame.sprite.Sprite.add(Player(CELL_SIZE - 4, block[0], block[1], RED), playerSprite)
                    cpuPoint = determineCpuCell()
                    pygame.sprite.Sprite.add(Player(CELL_SIZE - 4, cpuPoint[0], cpuPoint[1], BLACK), cpuSprite)

        if winner != 0:
            font = pygame.font.Font(None, 64)
            winnerTxt = ""
            if winner == 1:
                winnerTxt = "You won!"
            if winner == 2:
                winnerTxt = "You lost!"
            text = font.render(winnerTxt, True, (10, 10, 10))
            textpos = text.get_rect(centerx = background.get_width() / 2, y = 10)
            background.blit(text, textpos)

        font = pygame.font.Font(None, 64)
        if len(textToPrint) > 0:
            text = font.render(textToPrint, True, WHITE)    
            textPos = text.get_rect(centerx = background.get_width() / 2, y = MAX_SCREEN_SIZE_Y - 40) 
            background.blit(text, textPos)
        block = getBlockPos(printMousePos)
        textToPrint = "X:{0}, Y:{1}".format(block[0], block[1])
        text = font.render(textToPrint, True, (10, 10, 10))
        textPos = text.get_rect(centerx = background.get_width() / 2, y = MAX_SCREEN_SIZE_Y - 40) 
        background.blit(text, textPos)

        screen.blit(background, (0, 0))
        hooverSprite.update()
        hooverSprite.draw(screen)
        playerSprite.update()
        playerSprite.draw(screen)
        cpuSprite.update()
        cpuSprite.draw(screen)

        pygame.display.flip()
        
        if playerUpdated:
            playerUpdated = False
            winner = getWinner()

if __name__ == '__main__':
    main()

