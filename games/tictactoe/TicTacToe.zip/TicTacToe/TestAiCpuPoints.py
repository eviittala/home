import AiCpuPoints
import unittest

# if you want to execute only one test at time
# python3 TestAiCpuPoints.py TestAiCpuPoints.test_secondMove4

class TestAiCpuPoints(unittest.TestCase):
    def setUp(self):
        self.cellSize = 20
        self.cellOffset = 21  # +1 since border is size of one
        self.maxScreenSizeX = self.cellOffset * 50 - 1
        self.maxScreenSizeY = self.cellOffset * 50 - 1
        self.aiCpuPoints = AiCpuPoints.AiCpuPoints(self.maxScreenSizeX, self.maxScreenSizeY, self.cellSize) 

    def getRealX(self, cordinate):
        """ Returns X cordinate, in real """
        return self.cellOffset * cordinate + self.cellSize / 2

    def getRealY(self, cordinate):
        """ Returns Y cordinate, in real """
        return self.cellOffset * cordinate + self.cellSize / 2

    def getVirtualX(self, cordinate):
        """ Returns X cordinate, in virtual"""
        return (cordinate - self.cellSize / 2) / self.cellOffset

    def getVirtualY(self, cordinate):
        """ Returns X cordinate, in virtual"""
        return (cordinate - self.cellSize / 2) / self.cellOffset
    
    def test_screenSizes(self):
        self.assertEqual(1049, self.aiCpuPoints.getMaxScreenSizeX())
        self.assertEqual(1049, self.aiCpuPoints.getMaxScreenSizeY())
        self.assertEqual(20, self.aiCpuPoints.getCellSize())

    def test_firstMove(self):
        playerPoints = [[[self.cellOffset + self.cellSize / 2, self.cellOffset + self.cellSize / 2], 0, 1]]
        self.aiCpuPoints.setPlayerPoints(playerPoints)
        XY = self.aiCpuPoints.getCpuPoint()
        if not (XY[0] == self.cellSize / 2 or XY[0] == self.cellOffset + self.cellSize / 2 or XY[0] == self.cellOffset * 2 + self.cellSize / 2): 
            self.fail("Incorrect X = {0}".format(XY[0]))
        if not (XY[1] == self.cellSize / 2 or XY[1] == self.cellOffset + self.cellSize / 2 or XY[1] == self.cellOffset * 2 + self.cellSize / 2): 
            self.fail("Incorrect Y = {0}".format(XY[1]))

    def test_firstMove2(self):
        playerPoints = [[[self.cellSize / 2, self.cellSize / 2], 0, 1]]
        self.aiCpuPoints.setPlayerPoints(playerPoints)
        XY = self.aiCpuPoints.getCpuPoint()
        if not (XY[0] == self.cellSize / 2 or XY[0] == self.cellOffset + self.cellSize / 2): 
            self.fail("Incorrect X = {0}".format(XY[0]))
        if not (XY[1] == self.cellSize / 2 or XY[1] == self.cellOffset + self.cellSize / 2): 
            self.fail("Incorrect Y = {0}".format(XY[1]))

    def test_sort(self):
        points = [0 for i in range(10)]
        for i in range(10):
            points[i] = [[self.cellOffset, self.cellOffset], 0, i]
        self.aiCpuPoints.setPlayerPoints(points.copy())
        self.aiCpuPoints.setCpuPoints(points.copy())
        points1 = self.aiCpuPoints.getPlayerPoints()
        points2 = self.aiCpuPoints.getCpuPoints()
        for i in range(10):
            self.assertEqual(9 - i, points1[i][2]) 
            self.assertEqual(9 - i, points2[i][2]) 
            
    def test_secondMove(self):
        playerPoints = [[[self.getRealX(4), self.getRealY(2)], 3, 2]]
        cpuPoints = [[[self.getRealX(3), self.getRealY(4)], 0, 1]]
        self.aiCpuPoints.setPlayerPoints(playerPoints)
        self.aiCpuPoints.setCpuPoints(cpuPoints)

        XY = self.aiCpuPoints.getCpuPoint()
        self.assertEqual(self.getRealX(2), XY[0])
        self.assertEqual(self.getRealY(4), XY[1])
            
    def test_secondMove2(self):
        playerPoints = [[[self.getRealX(4), self.getRealY(2)], 3, 2]]
        cpuPoints = [[[self.getRealX(5), self.getRealY(2)], 0, 1]]
        self.aiCpuPoints.setPlayerPoints(playerPoints)
        self.aiCpuPoints.setCpuPoints(cpuPoints)

        XY = self.aiCpuPoints.getCpuPoint()
        print("TEST point {0} {1}".format(self.getVirtualX(XY[0]), self.getVirtualY(XY[1])))
        self.assertEqual(5, self.getVirtualX(XY[0]))
        self.assertEqual(1, self.getVirtualY(XY[1]))
            
    def test_secondMove3(self):
        playerPoints = [[[self.getRealX(4), self.getRealY(2)], 3, 2]]
        cpuPoints = [[[self.getRealX(4), self.getRealY(3)], 0, 1]]
        self.aiCpuPoints.setPlayerPoints(playerPoints)
        self.aiCpuPoints.setCpuPoints(cpuPoints)

        XY = self.aiCpuPoints.getCpuPoint()
        self.assertEqual(2, self.getVirtualX(XY[0]))
        self.assertEqual(4, self.getVirtualY(XY[1]))
            
    def test_secondMove4(self):
        playerPoints = [[[self.getRealX(4), self.getRealY(4)], 3, 3]]
        cpuPoints = [[[self.getRealX(3), self.getRealY(3)], 0, 2]]
        self.aiCpuPoints.setPlayerPoints(playerPoints)
        self.aiCpuPoints.setCpuPoints(cpuPoints)

        XY = self.aiCpuPoints.getCpuPoint()
        self.assertEqual(5, self.getVirtualX(XY[0]))
        self.assertEqual(3, self.getVirtualY(XY[1]))
            
    def test_cpuMove(self):
        playerPoints = [[[self.getRealX(6), self.getRealY(1)], 3, 3]]
        cpuPoints = [[[self.getRealX(3), self.getRealY(4)], 0, 2]]
        self.aiCpuPoints.setPlayerPoints(playerPoints)
        self.aiCpuPoints.setCpuPoints(cpuPoints)

        XY = self.aiCpuPoints.getCpuPoint()
        self.assertEqual(2, self.getVirtualX(XY[0]))
        self.assertEqual(4, self.getVirtualY(XY[1]))
            
    def test_cpuMove2(self):
        playerPoints = [[[self.getRealX(3), self.getRealY(2)], 1, 3], [[self.getRealX(7), self.getRealY(7)], 0, 1]]
        cpuPoints = [[[self.getRealX(7), self.getRealY(4)], 2, 3]]
        self.aiCpuPoints.setPlayerPoints(playerPoints)
        self.aiCpuPoints.setCpuPoints(cpuPoints)

        XY = self.aiCpuPoints.getCpuPoint()
        self.assertEqual(7, self.getVirtualX(XY[0]))
        self.assertEqual(3, self.getVirtualY(XY[1]))
            
    def test_cpuMove3(self):
        playerPoints = [[[self.getRealX(3), self.getRealY(2)], 1, 3]]
        cpuPoints = [[[self.getRealX(7), self.getRealY(5)], 2, 2]]
        self.aiCpuPoints.setPlayerPoints(playerPoints)
        self.aiCpuPoints.setCpuPoints(cpuPoints)

        XY = self.aiCpuPoints.getCpuPoint()
        print("TEST point {0} {1}".format(self.getVirtualX(XY[0]), self.getVirtualY(XY[1])))
        self.assertEqual(6, self.getVirtualX(XY[0]))
        self.assertEqual(5, self.getVirtualY(XY[1]))
            
    def test_cpuMove4(self):
        playerPoints = [[[self.getRealX(11), self.getRealY(2)], 3, 3], [[self.getRealX(7), self.getRealY(7)], 0, 1]]
        cpuPoints = [[[self.getRealX(7), self.getRealY(4)], 2, 3]]
        self.aiCpuPoints.setPlayerPoints(playerPoints)
        self.aiCpuPoints.setCpuPoints(cpuPoints)

        XY = self.aiCpuPoints.getCpuPoint()
        print("TEST point {0} {1}".format(self.getVirtualX(XY[0]), self.getVirtualY(XY[1])))
        self.assertEqual(7, self.getVirtualX(XY[0]))
        self.assertEqual(3, self.getVirtualY(XY[1]))
            
    def test_cpuMove5(self):
        playerPoints = [[[self.getRealX(11), self.getRealY(2)], 3, 3], [[self.getRealX(7), self.getRealY(7)], 0, 1], [[self.getRealX(7), self.getRealY(2)], 0, 1]]
        cpuPoints = [[[self.getRealX(7), self.getRealY(3)], 2, 4]]
        self.aiCpuPoints.setPlayerPoints(playerPoints)
        self.aiCpuPoints.setCpuPoints(cpuPoints)

        XY = self.aiCpuPoints.getCpuPoint()
        print("TEST point {0} {1}".format(self.getVirtualX(XY[0]), self.getVirtualY(XY[1])))
        self.assertEqual(8, self.getVirtualX(XY[0]))
        self.assertEqual(5, self.getVirtualY(XY[1]))
            
    def test_cpuMove6(self):
        playerPoints = [[[self.getRealX(3), self.getRealY(2)], 1, 3], [[self.getRealX(10), self.getRealY(10)], 0, 1]]
        cpuPoints = [[[self.getRealX(7), self.getRealY(5)], 0, 3]]
        self.aiCpuPoints.setPlayerPoints(playerPoints)
        self.aiCpuPoints.setCpuPoints(cpuPoints)

        XY = self.aiCpuPoints.getCpuPoint()
        self.assertEqual(6, self.getVirtualX(XY[0]))
        self.assertEqual(5, self.getVirtualY(XY[1]))
            
    def test_cpuMove7(self):
        playerPoints = [[[self.getRealX(6), self.getRealY(1)], 2, 2], [[self.getRealX(6), self.getRealY(4)], 2, 2]]
        cpuPoints = [[[self.getRealX(2), self.getRealY(2)], 1, 3]]
        self.aiCpuPoints.setPlayerPoints(playerPoints)
        self.aiCpuPoints.setCpuPoints(cpuPoints)

        XY = self.aiCpuPoints.getCpuPoint()
        print("TEST point {0} {1}".format(self.getVirtualX(XY[0]), self.getVirtualY(XY[1])))
        self.assertEqual(1, self.getVirtualX(XY[0]))
        self.assertEqual(1, self.getVirtualY(XY[1]))
            
    def test_cpuMove8(self):
        playerPoints = [[[self.getRealX(6), self.getRealY(1)], 2, 2], [[self.getRealX(6), self.getRealY(4)], 2, 1], [[self.getRealX(4), self.getRealY(4)], 0, 1]]
        cpuPoints = [[[self.getRealX(1), self.getRealY(1)], 1, 3]]
        self.aiCpuPoints.setPlayerPoints(playerPoints)
        self.aiCpuPoints.setCpuPoints(cpuPoints)

        XY = self.aiCpuPoints.getCpuPoint()
        print("TEST point {0} {1}".format(self.getVirtualX(XY[0]), self.getVirtualY(XY[1])))
        self.assertEqual(6, self.getVirtualX(XY[0]))
        self.assertEqual(3, self.getVirtualY(XY[1]))
            
    def test_cpuMove9(self):
        playerPoints = [[[self.getRealX(6), self.getRealY(1)], 2, 2], [[self.getRealX(6), self.getRealY(4)], 2, 3]]
        cpuPoints = [[[self.getRealX(2), self.getRealY(2)], 1, 3], [[self.getRealX(6), self.getRealY(3)], 0, 1]]
        self.aiCpuPoints.setPlayerPoints(playerPoints)
        self.aiCpuPoints.setCpuPoints(cpuPoints)

        XY = self.aiCpuPoints.getCpuPoint()
        print("TEST point {0} {1}".format(self.getVirtualX(XY[0]), self.getVirtualY(XY[1])))
        self.assertEqual(1, self.getVirtualX(XY[0]))
        self.assertEqual(1, self.getVirtualY(XY[1]))
            
    def test_cpuMove10(self):
        playerPoints = [[[self.getRealX(4), self.getRealY(4)], 1, 3], [[self.getRealX(2), self.getRealY(6)], 0, 1]]
        cpuPoints = [[[self.getRealX(4), self.getRealY(3)], 3, 3]]
        self.aiCpuPoints.setPlayerPoints(playerPoints)
        self.aiCpuPoints.setCpuPoints(cpuPoints)

        XY = self.aiCpuPoints.getCpuPoint()
        print("TEST point {0} {1}".format(self.getVirtualX(XY[0]), self.getVirtualY(XY[1])))
        self.assertEqual(5, self.getVirtualX(XY[0]))
        self.assertEqual(2, self.getVirtualY(XY[1]))
            
    def test_cpuMove11(self):
        playerPoints = [[[self.getRealX(6), self.getRealY(3)], 1, 4]]
        cpuPoints = [[[self.getRealX(5), self.getRealY(2)], 2, 3]]
        self.aiCpuPoints.setPlayerPoints(playerPoints)
        self.aiCpuPoints.setCpuPoints(cpuPoints)

        XY = self.aiCpuPoints.getCpuPoint()
        print("TEST point {0} {1}".format(self.getVirtualX(XY[0]), self.getVirtualY(XY[1])))
        self.assertEqual(10, self.getVirtualX(XY[0]))
        self.assertEqual(7, self.getVirtualY(XY[1]))
            
    def test_cpuMove12(self):
        playerPoints = [[[self.getRealX(6), self.getRealY(2)], 3, 3]]
        cpuPoints = [[[self.getRealX(3), self.getRealY(5)], 0, 1], [[self.getRealX(5), self.getRealY(4)], 0, 1]]
        self.aiCpuPoints.setPlayerPoints(playerPoints)
        self.aiCpuPoints.setCpuPoints(cpuPoints)

        XY = self.aiCpuPoints.getCpuPoint()
        print("TEST point {0} {1}".format(self.getVirtualX(XY[0]), self.getVirtualY(XY[1])))
        self.assertEqual(7, self.getVirtualX(XY[0]))
        self.assertEqual(1, self.getVirtualY(XY[1]))
            
    def test_cpuMove13(self):
        playerPoints = [[[self.getRealX(3), self.getRealY(3)], 0, 3], [[self.getRealX(2), self.getRealY(1)], 0, 1], [[self.getRealX(2), self.getRealY(5)], 0, 1]]
        cpuPoints = [[[self.getRealX(2), self.getRealY(2)], 2, 3], [[self.getRealX(6), self.getRealY(3)], 0, 1]]
        self.aiCpuPoints.setPlayerPoints(playerPoints)
        self.aiCpuPoints.setCpuPoints(cpuPoints)

        XY = self.aiCpuPoints.getCpuPoint()
        print("TEST point {0} {1}".format(self.getVirtualX(XY[0]), self.getVirtualY(XY[1])))
        virtualXY = [self.getVirtualX(XY[0]), self.getVirtualY(XY[1])]
        if not (virtualXY[0] > 4 and virtualXY[0] < 8 and virtualXY[1] > 1 and virtualXY[1] < 5):
            self.fail("Incorrect values virtualXY: {0}".format(virtualXY))
            
    def test_cpuMove14(self):
        playerPoints = [[[self.getRealX(3), self.getRealY(3)], 1, 2], [[self.getRealX(4), self.getRealY(4)], 3, 2], [[self.getRealX(3), self.getRealY(5)], 2, 2]]
        cpuPoints = [[[self.getRealX(5), self.getRealY(3)], 0, 1], [[self.getRealX(5), self.getRealY(5)], 0, 1], [[self.getRealX(2), self.getRealY(6)], 0, 1]]
        self.aiCpuPoints.setPlayerPoints(playerPoints)
        self.aiCpuPoints.setCpuPoints(cpuPoints)

        XY = self.aiCpuPoints.getCpuPoint()
        print("TEST point {0} {1}".format(self.getVirtualX(XY[0]), self.getVirtualY(XY[1])))
        self.assertEqual(3, self.getVirtualX(XY[0]))
        self.assertEqual(7, self.getVirtualY(XY[1]))

unittest.main()
