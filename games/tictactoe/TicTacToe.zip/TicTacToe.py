#!/usr/bin/python

import sys, pygame, random, GameLogic
from pygame.locals import *

WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
BLACK = (0, 0, 0)
BLUE = (0, 0, 255)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)
GRAY = (220, 220, 220)
CELL_SIZE = 20
CELL_OFFSET = CELL_SIZE + 1
MAX_SIZE_X = 50
MAX_SIZE_Y = 50
MAX_SCREEN_SIZE_X = (CELL_OFFSET) * MAX_SIZE_X - 1
MAX_SCREEN_SIZE_Y = (CELL_OFFSET) * MAX_SIZE_Y - 1
HOOVER = [[5, 5]]
OFFSETS = {0 : [CELL_OFFSET, 0], 1 : [CELL_OFFSET, CELL_OFFSET], 2 : [0, CELL_OFFSET], 3 : [-(CELL_OFFSET), CELL_OFFSET]}
COUNTEROFFSETS = {0 : [-(CELL_OFFSET), 0], 1 : [-(CELL_OFFSET), -(CELL_OFFSET)], 2 : [0, -(CELL_OFFSET)], 3 : [CELL_OFFSET, -(CELL_OFFSET)]}
gameLogic = GameLogic.GameLogic(MAX_SIZE_X, MAX_SIZE_Y)
WINNER_XYS = []

def getBlockPos(mousePos):
    ret = [0, 0]

    for posX in range (CELL_SIZE, MAX_SCREEN_SIZE_X + 1, CELL_OFFSET):
        if mousePos[0] < posX:
            ret[0] = posX - CELL_SIZE / 2
            break
    for posY in range (CELL_SIZE, MAX_SCREEN_SIZE_Y + 1, CELL_OFFSET):
        if mousePos[1] < posY:
            ret[1] = posY - CELL_SIZE / 2
            break

    return ret;        

class Hoover(pygame.sprite.Sprite):
    """Hoover"""

    def __init__(self, size):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface([size, size])
        self.image.fill(GRAY)
        self.rect = self.image.get_rect()
        self.area = screen.get_rect()

    def update(self):
        mousePos = pygame.mouse.get_pos()
        self.rect.center = getBlockPos(mousePos)
        
class Player(pygame.sprite.Sprite):
    """ Player spirit """

    def __init__(self, size, x, y, color):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface([size, size])
        self.image.fill(WHITE)
        self.rect = self.image.get_rect()
        self.area = screen.get_rect()
        self.rect.center = [x, y]
        self.offset = 5
        self.size = size
        self.color = color
        pygame.draw.aaline(self.image, self.color, ((self.size / 2) - self.offset - 1, (self.size / 2) - self.offset), ((self.size / 2) + self.offset - 1, (self.size / 2) + self.offset))
        pygame.draw.aaline(self.image, self.color, ((self.size / 2) - self.offset, (self.size / 2) - self.offset), ((self.size / 2) + self.offset, (self.size / 2) + self.offset))
        pygame.draw.aaline(self.image, self.color, ((self.size / 2) - self.offset + 1, (self.size / 2) - self.offset), ((self.size / 2) + self.offset + 1, (self.size / 2) + self.offset))
        pygame.draw.aaline(self.image, self.color, ((self.size / 2) - self.offset - 1, (self.size / 2) + self.offset), ((self.size / 2) + self.offset - 1, (self.size / 2) - self.offset))
        pygame.draw.aaline(self.image, self.color, ((self.size / 2) - self.offset, (self.size / 2) + self.offset), ((self.size / 2) + self.offset, (self.size / 2) - self.offset))
        pygame.draw.aaline(self.image, self.color, ((self.size / 2) - self.offset + 1, (self.size / 2) + self.offset), ((self.size / 2) + self.offset + 1, (self.size / 2) - self.offset))

    def update(self):
        if WINNER_XYS:
            for xy in WINNER_XYS:
                if self.rect.center[0] == xy[0] and self.rect.center[1] == xy[1]:
                    self.image.fill(YELLOW)
                    pygame.draw.aaline(self.image, self.color, ((self.size / 2) - self.offset - 1, (self.size / 2) - self.offset), ((self.size / 2) + self.offset - 1, (self.size / 2) + self.offset))
                    pygame.draw.aaline(self.image, self.color, ((self.size / 2) - self.offset, (self.size / 2) - self.offset), ((self.size / 2) + self.offset, (self.size / 2) + self.offset))
                    pygame.draw.aaline(self.image, self.color, ((self.size / 2) - self.offset + 1, (self.size / 2) - self.offset), ((self.size / 2) + self.offset + 1, (self.size / 2) + self.offset))
                    pygame.draw.aaline(self.image, self.color, ((self.size / 2) - self.offset - 1, (self.size / 2) + self.offset), ((self.size / 2) + self.offset - 1, (self.size / 2) - self.offset))
                    pygame.draw.aaline(self.image, self.color, ((self.size / 2) - self.offset, (self.size / 2) + self.offset), ((self.size / 2) + self.offset, (self.size / 2) - self.offset))
                    pygame.draw.aaline(self.image, self.color, ((self.size / 2) - self.offset + 1, (self.size / 2) + self.offset), ((self.size / 2) + self.offset + 1, (self.size / 2) - self.offset))

    def getXY(self):
        return [self.rect.center[0], self.rect.center[1]]
        
class Cpu(pygame.sprite.Sprite):
    """ CPU spirit """

    def __init__(self, size, x, y, color):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface([size, size])
        self.image.fill(WHITE)
        self.rect = self.image.get_rect()
        self.area = screen.get_rect()
        self.rect.center = [x, y]
        self.color = color
        self.size = size
        pygame.draw.circle(self.image, color, (size//2, size//2), 8, 2)

    def update(self):
        if WINNER_XYS:
            for xy in WINNER_XYS:
                if self.rect.center[0] == xy[0] and self.rect.center[1] == xy[1]:
                    self.image.fill(YELLOW)
                    pygame.draw.circle(self.image, self.color, (self.size//2, self.size//2), 8, 2)
                    break

    def getXY(self):
        return [self.rect.center[0], self.rect.center[1]]
 
def getVirtualXY(coordinateX, coordinateY):
    """ Returns XY in virtual 0...49 """
    virtual = lambda x : (x - CELL_SIZE / 2) / CELL_OFFSET
    return [virtual(coordinateX), virtual(coordinateY)]

def getRealXY(virtualX, virtualY):
    """ Returns realXY """
    real = lambda x : (CELL_OFFSET * x + CELL_SIZE / 2)
    return [real(virtualX), real(virtualY)]

def main():
    pygame.init()
    global screen
    global playerSprite
    global cpuSprite
    screen = pygame.display.set_mode((MAX_SCREEN_SIZE_X, MAX_SCREEN_SIZE_Y))
    pygame.display.set_caption('Eeros TicTacToe')
    screen.fill(WHITE)
    hoover = Hoover(CELL_SIZE)
    cpu = Cpu(CELL_SIZE - 2, 31, 31, BLACK)
    hooverSprite = pygame.sprite.RenderPlain((hoover))
    playerSprite = pygame.sprite.Group()
    cpuSprite = pygame.sprite.Group()
    background = pygame.Surface(screen.get_size())
    background = background.convert()
    background.fill(WHITE)
    for pos in range (CELL_SIZE, MAX_SCREEN_SIZE_X, CELL_OFFSET):
        pygame.draw.line(background, BLACK, [0, pos], [MAX_SCREEN_SIZE_X, pos], 1)
        pygame.draw.line(background, BLACK, [pos, 0], [pos, MAX_SCREEN_SIZE_Y], 1)
    screen.blit(background, (0, 0))

    pygame.display.flip()

    playerUpdated = False
    printMousePos = [0, 0]
    textToPrint = ""
    printPoints = True
    winner = 0
    while True:
        for event in pygame.event.get():
            if event.type == QUIT:
                return
            if event.type == MOUSEMOTION:
                printMousePos = pygame.mouse.get_pos()
            if event.type == MOUSEBUTTONDOWN and not playerUpdated and winner == 0:    
                mousePos = pygame.mouse.get_pos()
                block = getBlockPos(mousePos)
                XY = getVirtualXY(block[0], block[1])
                try:
                    gameLogic.addPlayerPoint(XY)
                    playerUpdated = True
                    pygame.sprite.Sprite.add(Player(CELL_SIZE - 2, block[0], block[1], RED), playerSprite)
                except(Exception):
                    pass

        winner = gameLogic.getWinner()
        if winner != 0:
            font = pygame.font.Font(None, 64)
            winnerTxt = ""
            if winner == 1:
                winnerTxt = "You won!"
            if winner == 2:
                winnerTxt = "You lost!"
            text = font.render(winnerTxt, True, (10, 10, 10))
            textpos = text.get_rect(centerx = background.get_width() / 2, y = 10)

            background.blit(text, textpos)
            if printPoints:
                gameLogic.printPoints()
                printPoints = False

        font = pygame.font.Font(None, 64)
        if len(textToPrint) > 0:
            text = font.render(textToPrint, True, WHITE)    
            textPos = text.get_rect(centerx = background.get_width() / 2, y = MAX_SCREEN_SIZE_Y - 40) 
            background.blit(text, textPos)
        block = getBlockPos(printMousePos)
        textToPrint = "X:{0}, Y:{1}".format(block[0], block[1])
        text = font.render(textToPrint, True, (10, 10, 10))
        textPos = text.get_rect(centerx = background.get_width() / 2, y = MAX_SCREEN_SIZE_Y - 40) 
        background.blit(text, textPos)

        if winner != 0:
            winnerXYs = gameLogic.getWinnerPoints(winner)
            if not WINNER_XYS:
                for xy in winnerXYs:
                    WINNER_XYS.append(getRealXY(xy[0], xy[1]))

        screen.blit(background, (0, 0))
        hooverSprite.update()
        hooverSprite.draw(screen)
        playerSprite.update()
        playerSprite.draw(screen)
        cpuSprite.update()
        cpuSprite.draw(screen)

        pygame.display.flip()
        
        if playerUpdated and winner == 0:
            playerUpdated = False
            cpuXY = gameLogic.getNextCpuPoint()
            cpuPoint = getRealXY(cpuXY[0], cpuXY[1])
            pygame.sprite.Sprite.add(Cpu(CELL_SIZE - 2, cpuPoint[0], cpuPoint[1], BLACK), cpuSprite)

if __name__ == '__main__':
    main()

