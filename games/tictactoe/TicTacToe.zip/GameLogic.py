import random

class GameLogic:
    def __init__(self, maxScreenSizeX, maxScreenSizeY):
        self.maxScreenSizeX = maxScreenSizeX
        self.maxScreenSizeY = maxScreenSizeY
        self.cpuPoints = []
        self.playerPoints = []
        self.cpuPoints = []
        self.offsets = {0 : [1, 0], 1 : [1, 1], 2 : [0, 1], 3 : [-1, 1], 4 : [-1, 0], 5 : [-1, -1], 6 : [0, -1], 7 : [1,  -1]}

    def getMaxX(self):
        return self.maxScreenSizeX

    def getMaxY(self):
        return self.maxScreenSizeY

    def addPlayerPoint(self, XY):
        """ AddPlayerPoint [XY] """
        if not self.__isValidPoint(XY):
            raise Exception("Not valid point {0}".format(XY))
        self.playerPoints.append(XY)

    def addCpuPoint(self, XY):
        """ CpuPoint [XY] """
        self.cpuPoints.append(XY)

    def getPlayerPoints(self):
        return self.__getAttachedPoints(self.playerPoints, "player")

    def getWinnerPoints(self, winner):
        retXYs = []
        if winner == 1:
            pointXY = self.__getAttachedPoints(self.playerPoints, "player")[0]
            for i in range(pointXY[2]):
                retXYs.append(self.__addOffsetToPoint(pointXY[0], pointXY[1], i))
        if winner == 2:
            pointXY = self.__getAttachedPoints(self.cpuPoints, "cpu")[0]
            for i in range(pointXY[2]):
                retXYs.append(self.__addOffsetToPoint(pointXY[0], pointXY[1], i))
        return retXYs

    def getNextCpuPoint(self):
        """ GetNextCpuPoint return XY """
        self.cpuPoints.append(self.__deduceNextMove())
        return self.cpuPoints[-1]

    def getWinner(self):
        """ Returns winner, 0 = none, 1 = player, 2 = cpu """
        try:
            if self.__getAttachedPoints(self.playerPoints, "player")[0][2] >= 5:
                return 1
        except(IndexError):
            pass
        try:
            if self.__getAttachedPoints(self.cpuPoints, "cpu")[0][2] >= 5:
                return 2
        except(IndexError):
            pass
        return 0

    def printPoints(self):
        print("Player: ", end = "")
        print(self.playerPoints);
        print("Cpu: ", end = "")
        print(self.cpuPoints);

    def __pointSort(self, point):
        return point[2]

    def __deduceNextMove(self):
        if len(self.playerPoints) == 1:
            ranDir = random.randrange(0, 8)
            retXY = self.__addOffsetToPoint(self.playerPoints[0], ranDir)
            while not self.__isValidPoint(retXY):
                ranDir = random.randrange(0, 8)
                retXY = self.__addOffsetToPoint(self.playerPoints[0], ranDir)
            return retXY
        else:
            pAttachedPoints = self.__getAttachedPoints(self.playerPoints, "player")
            cAttachedPoints = self.__getAttachedPoints(self.cpuPoints, "cpu")
            pLen = 0
            cLen = 0
            if 0 < len(pAttachedPoints):
                pLen = pAttachedPoints[0][2]
            if 0 < len(cAttachedPoints):
                cLen = cAttachedPoints[0][2]
            cXYPrio = []
            pXYPrio = []
            cXYs = []
            pXYs = []
            for y in range(self.maxScreenSizeY):
                for x in range(self.maxScreenSizeX):
                    if self.__isValidPoint([x, y]):
                        cPoints = self.cpuPoints.copy()
                        pPoints = self.playerPoints.copy()
                        cPoints.append([x, y])
                        pPoints.append([x, y])
                        cAttachedPoints = self.__getAttachedPoints(cPoints, "cpu")
                        pAttachedPoints = self.__getAttachedPoints(pPoints, "player")
                        try:
                            if (cAttachedPoints[0][2] > cLen):
                                cXYs.append([x, y])
                            if (pAttachedPoints[0][2] > pLen):
                                pXYs.append([x, y])
                        except(IndexError):
                            pass

            if cXYs:
                cXYPrio = self.__determineBestPoint(cXYs, self.cpuPoints)
            if pXYs:
                pXYPrio = self.__determineBestPoint(pXYs, self.playerPoints)

            if len(pXYPrio) > 0 and pXYPrio[0][1] > 0 and pXYPrio[0][1] > cXYPrio[0][1]:
                pPriority = pXYPrio[0][1]
                pXYs = []
                for pItemXYP in pXYPrio:
                    if pItemXYP[1] == pPriority:
                        pXYs.append(pItemXYP[0])
                    else:
                        break

                if len(pXYs) == 1:
                    return pXYs[0]
                else:
                    for cXYP in cXYPrio:
                        for pXY in pXYs:
                            if self.__isSame(pXY, cXYP[0]):
                                return pXY;
                return pXYs[0]
            else:
                cPriority = cXYPrio[0][1]
                cXYs = []
                for itemXYP in cXYPrio:
                    if itemXYP[1] == cPriority:
                        cXYs.append(itemXYP[0])
                mXY = []

                for i in range(len(cXYs)):
                    for j in range(i + 1, len(cXYs)):
                        if self.__isSame(cXYs[i], cXYs[j]):
                            if cXYs[i] not in mXY:
                                mXY.append(cXYs[i])
                if mXY:
                    return mXY[0]

                for iXYP in cXYPrio:
                    if iXYP[1] != cPriority:
                        for XY in cXYs:
                            if self.__isSame(XY, iXYP[0]):
                                mXY.append(XY)
                if mXY:
                    return mXY[0]

                return cXYPrio[0][0]
    
    def __determineBestPoint(self, bestPointsXY, pointsXY):
        """ returns [XY, prio], pointsXY is either self.playerPoints or self.cpuPoints  """ 
        # Marks     Prio
        #   0XX     0
        #    XX     1
        #  0XXX     2
        #   XXX     3
        # 0XXXX     4
        #  XXXX     5
        #0XXXXX     6
        # XXXXX     7
        pointsWithPrio = []
        prioList = {2 : 1, 3 : 3, 4 : 5, 5 : 7, 6 : 9}
        for XY in bestPointsXY:
            for d in range(int(len(self.offsets) / 2)):
                length = 1
                rightXY = self.__addOffsetToPoint(XY, d)
                while self.__isHit(pointsXY, rightXY):
                    length += 1
                    rightXY = self.__addOffsetToPoint(rightXY, d)

                leftXY = self.__addOffsetToPoint(XY, d + 4)
                while self.__isHit(pointsXY, leftXY):
                    length += 1
                    leftXY = self.__addOffsetToPoint(leftXY, d + 4)

                lowPrio = 0
                if not self.__isValidPoint(leftXY) or not self.__isValidPoint(rightXY):
                    lowPrio = 1

                try:
                    pointsWithPrio.append([XY, prioList[length] - lowPrio])    
                except KeyError:
                    pass
                    # print("XY: {0} has length: {1}".format(XY, length));
       
        pointsWithPrio.sort(reverse = True, key = lambda x : x[1]) 
        # print("determineBestPoint: {0}".format(pointsWithPrio));
        return pointsWithPrio


            
    def __addOffsetToPoint(self, XY, offsetNbr, length=1):
        """ Add offsetNbr to point XY and returns the result """
        offset = self.offsets[offsetNbr]
        return [XY[0] + offset[0] * length, XY[1] + offset[1] * length]

    def __isValidPoint(self, XY, who = "none"):
        if not self.__isPointInsideWindow(XY):
            return False
        if who != "player" and self.__isHit(self.playerPoints, XY):
            return False
        if who != "cpu" and self.__isHit(self.cpuPoints, XY):
            return False
        return True

    def __isPointInsideWindow(self, XY):
        if XY[0] < 0 or self.maxScreenSizeX <= XY[0]:
            return False
        if XY[1] < 0 or self.maxScreenSizeY <= XY[1]:
            return False
        return True

    def __isSame(self, XY1, XY2):
        """ IsSame checks if XY1 == XY2 """
        return XY1[0] == XY2[0] and XY1[1] == XY2[1]

    def __isHit(self, pointsXY, XY):
        """ IsHit return True if XY is can be found at points, otherwise False is returned """
        for point in pointsXY:
            if self.__isSame(XY, point):
                return True
        return False

    def __getAttachedPoints(self, points, who):
        """ Get list of points, returns [[XY], dir, len] """
        retPoints = []
        for pointXY in points:
            #print("Scanning {0}".format(pointXY))
            isAttached = False
            for d in range(int(len(self.offsets) / 2)):
                rightXY = self.__addOffsetToPoint(pointXY, d)
                leftXY = self.__addOffsetToPoint(pointXY, d + 4)
                isRightXyHit = False
                if self.__isPointInsideWindow(rightXY):
                    isRightXyHit = self.__isHit(points, rightXY)
                isLeftXyHit = False
                if self.__isPointInsideWindow(leftXY): 
                    isLeftXyHit = self.__isHit(points, leftXY)
                if not isLeftXyHit and isRightXyHit:
                    length = 2
                    rightXY = self.__addOffsetToPoint(rightXY, d)

                    while self.__isHit(points, rightXY):
                        length = length + 1
                        rightXY = self.__addOffsetToPoint(rightXY, d)

                    possibleLeftLen = 0;
                    possibleRightLen = 0;

                    while self.__isValidPoint(leftXY, who) and possibleLeftLen < 5:
                        possibleLeftLen += 1
                        leftXY = self.__addOffsetToPoint(leftXY, d + 4)

                    while self.__isValidPoint(rightXY, who) and possibleRightLen < 5:
                        possibleRightLen += 1
                        rightXY = self.__addOffsetToPoint(rightXY, d)

                    if length + possibleLeftLen + possibleRightLen >= 5:
                        retPoints.append([pointXY, d, length])

                if isLeftXyHit or isRightXyHit:
                    isAttached = True
           
            if not isAttached:
                retPoints.append([pointXY, 8, 1])
        retPoints.sort(reverse = True, key = self.__pointSort)        
        return retPoints

if __name__ == "__main__":
    gameLogic = GameLogic(50, 50)
    try:
        while True:
            x, y = [int(val) for val in input("Give X Y: ").split()]
            #y = int(input("Give Y: "))
            gameLogic.addPlayerPoint([x, y])
            print("Cpu XY: {0}".format(gameLogic.getNextCpuPoint()))
            winner = gameLogic.getWinner()
            if winner != 0:
                if winner == 1:
                    print("You won!")
                else:
                    print("You lost!");
                break;
    except IndexError as err:
        print("IndexError: {0}".format(err));
        
    gameLogic.printPoints()
