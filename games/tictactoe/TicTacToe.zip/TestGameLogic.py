import GameLogic
import unittest

class TestGameLogic(unittest.TestCase):
    def setUp(self):
        self.maxX = 100
        self.maxY = 150
        self.gameLogic = GameLogic.GameLogic(self.maxX, self.maxY)

    def tearDown(self):
        pass

    def addPlayerPoints(self, pointsXY):
        for xy in pointsXY:
            self.gameLogic.addPlayerPoint(xy)

    def addCpuPoints(self, pointsXY):
        for xy in pointsXY:
            self.gameLogic.addCpuPoint(xy)

    def test_getters(self):
        self.assertEqual(100, self.gameLogic.getMaxX())
        self.assertEqual(150, self.gameLogic.getMaxY())

    def test_duplicate(self):
        playerPoints = [[5, 6], [5, 6]] 
        self.assertRaises(Exception, self.gameLogic.addPlayerPoint, playerPoints)
    
    def test_firstMove(self):
        playerPoint = [5, 6] 
        self.gameLogic.addPlayerPoint(playerPoint)         
        XY = self.gameLogic.getNextCpuPoint()
        self.assertTrue(4 ==  XY[0] or 5 == XY[0] or 6 == XY[0])
        self.assertTrue(5 ==  XY[1] or 6 == XY[1] or 7 == XY[1])
    
    def test_firstMoveCorner1(self):
        playerPoint = [0, 0] 
        self.gameLogic.addPlayerPoint(playerPoint)         
        XY = self.gameLogic.getNextCpuPoint()
        self.assertTrue(0 ==  XY[0] or 1 == XY[0])
        self.assertTrue(0 ==  XY[1] or 1 == XY[1])
    
    def test_firstMoveCorner2(self):
        playerPoint = [self.maxX - 1, self.maxY - 1] 
        self.gameLogic.addPlayerPoint(playerPoint)         
        XY = self.gameLogic.getNextCpuPoint()
        self.assertTrue(self.maxX - 2 ==  XY[0] or self.maxX - 1 == XY[0])
        self.assertTrue(self.maxY - 2 ==  XY[1] or self.maxY - 1 == XY[1])

    def test_attachingPoints(self):
        self.gameLogic.addPlayerPoint([2, 2])         
        self.gameLogic.addPlayerPoint([3, 2])         
        self.gameLogic.addPlayerPoint([4, 2])         
        points = self.gameLogic.getPlayerPoints()
        self.assertEqual(1, len(points))
        self.assertEqual(2, points[0][0][0])
        self.assertEqual(2, points[0][0][1])
        self.assertEqual(0, points[0][1])
        self.assertEqual(3, points[0][2])

    def test_attachingPoints2(self):
        self.gameLogic.addPlayerPoint([2, 2])         
        self.gameLogic.addPlayerPoint([3, 3])         
        self.gameLogic.addPlayerPoint([4, 4])         
        points = self.gameLogic.getPlayerPoints()
        self.assertEqual(1, len(points))
        self.assertEqual(2, points[0][0][0])
        self.assertEqual(2, points[0][0][1])
        self.assertEqual(1, points[0][1])
        self.assertEqual(3, points[0][2])

    def test_attachingPoints3(self):
        self.gameLogic.addPlayerPoint([4, 5])         
        self.gameLogic.addPlayerPoint([3, 4])         
        self.gameLogic.addPlayerPoint([2, 3])         
        points = self.gameLogic.getPlayerPoints()
        self.assertEqual(1, len(points))
        self.assertEqual(2, points[0][0][0])
        self.assertEqual(3, points[0][0][1])
        self.assertEqual(1, points[0][1])
        self.assertEqual(3, points[0][2])

    def test_attachingPoints4(self):
        self.gameLogic.addPlayerPoint([4, 5])         
        self.gameLogic.addPlayerPoint([3, 4])         
        self.gameLogic.addPlayerPoint([2, 3])         
        self.gameLogic.addPlayerPoint([4, 3])         
        points = self.gameLogic.getPlayerPoints()
        self.assertEqual(2, len(points))
        self.assertEqual(2, points[0][0][0])
        self.assertEqual(3, points[0][0][1])
        self.assertEqual(1, points[0][1])
        self.assertEqual(3, points[0][2])
        self.assertEqual(4, points[1][0][0])
        self.assertEqual(3, points[1][0][1])
        self.assertEqual(3, points[1][1])
        self.assertEqual(2, points[1][2])

    def test_attachingPoints5(self):
        self.gameLogic.addPlayerPoint([4, 5])         
        self.gameLogic.addPlayerPoint([3, 4])         
        self.gameLogic.addPlayerPoint([2, 3])         
        self.gameLogic.addPlayerPoint([4, 3])         
        self.gameLogic.addPlayerPoint([6, 3])         
        points = self.gameLogic.getPlayerPoints()
        expectedPoints = [[[2, 3], 1, 3], [[4, 3], 3, 2], [[6, 3], 8, 1]]
        self.assertEqual(3, len(points))
        self.assertEqual(expectedPoints, points)

    def test_attachingPoints6(self):
        self.gameLogic.addPlayerPoint([4, 5])         
        self.gameLogic.addPlayerPoint([3, 4])         
        self.gameLogic.addPlayerPoint([2, 3])         
        self.gameLogic.addPlayerPoint([4, 3])         
        self.gameLogic.addPlayerPoint([6, 3])         
        self.gameLogic.addPlayerPoint([5, 4])         
        points = self.gameLogic.getPlayerPoints()
        expectedPoints = [[[2, 3], 1, 3], [[6, 3], 3, 3], [[4, 3], 1, 2], [[4, 3], 3, 2]]
        self.assertEqual(4, len(points))
        self.assertEqual(expectedPoints, points)

    def test_attachingPoints7(self):
        self.gameLogic.addPlayerPoint([4, 2])         
        self.gameLogic.addPlayerPoint([3, 3])         
        self.gameLogic.addPlayerPoint([2, 4])         
        self.gameLogic.addCpuPoint([5, 1])         
        self.gameLogic.addCpuPoint([1, 5])         
        self.gameLogic.addCpuPoint([5, 2])         
        points = self.gameLogic.getPlayerPoints()
        expectedPoints = []
        self.assertEqual(0, len(points))

    def test_attachingPoints8(self):
        self.gameLogic.addPlayerPoint([4, 2])         
        self.gameLogic.addPlayerPoint([3, 3])         
        self.gameLogic.addPlayerPoint([2, 4])         
        self.gameLogic.addCpuPoint([5, 1])         
        self.gameLogic.addCpuPoint([5, 2])         
        self.gameLogic.addCpuPoint([5, 3])         
        points = self.gameLogic.getPlayerPoints()
        expectedPoints = [[[4, 2], 3, 3]]
        self.assertEqual(1, len(points))
        self.assertEqual(expectedPoints, points)

    def test_attachingPoints9(self):
        self.gameLogic.addPlayerPoint([1, 2])         
        self.gameLogic.addPlayerPoint([1, 3])         
        self.gameLogic.addCpuPoint([1, 4])         
        self.gameLogic.addCpuPoint([1, 5])         
        points = self.gameLogic.getPlayerPoints()
        expectedPoints = []
        self.assertEqual(0, len(points))
        self.assertEqual(expectedPoints, points)
    
    def test_moves(self):
        playerPoint = [self.maxX - 1, self.maxY - 1] 
        self.gameLogic.addPlayerPoint(playerPoint)         
        XY = self.gameLogic.getNextCpuPoint()
        #print("getNextCpuPoint: {0}".format(XY))
        self.assertTrue(self.maxX - 2 ==  XY[0] or self.maxX - 1 == XY[0])
        self.assertTrue(self.maxY - 2 ==  XY[1] or self.maxY - 1 == XY[1])

    def test_moves2(self):
        playerPoints = [[4, 4], [6, 4], [5, 3], [5, 7], [3, 5], [4, 6], [4, 5], [4, 7], [3, 7]]
        cpuPoints =    [[5, 5], [5, 4], [5, 6], [4, 2], [6, 2], [2, 4], [4, 3], [4, 8]]
        self.addPlayerPoints(playerPoints)
        self.addCpuPoints(cpuPoints)
        XY = self.gameLogic.getNextCpuPoint()
        #print("Next Cpu point: {0}".format(XY))
        self.assertTrue(2 ==  XY[0])
        self.assertTrue(7 ==  XY[1])
        # self.gameLogic.printPoints()
        winner = self.gameLogic.getWinner()
        self.assertTrue(winner == 0)

    def test_moves3(self):
        playerPoints = [[5, 5], [6, 4], [7, 4], [8, 5], [7, 6], [2, 1], [5, 3], [4, 5], [9, 0], [10, 3], [6, 1], [11, 6], [6, 7], [5, 6], [4, 6], [7, 7], [4, 7], [4, 8], [4, 9]]
        cpuPoints =    [[6, 5], [7, 3], [5, 4], [4, 3], [3, 2], [6, 3], [7, 2], [8, 1], [8, 3], [9, 4], [10, 5], [4, 2], [5, 8], [3, 4], [6, 6], [7, 5], [5, 7], [4, 4]]
        self.addPlayerPoints(playerPoints)
        self.addCpuPoints(cpuPoints)
        XY = self.gameLogic.getNextCpuPoint()
        #print("Next Cpu point: {0}".format(XY))
        self.assertTrue(4 ==  XY[0])
        self.assertTrue(10 ==  XY[1])
        # self.gameLogic.printPoints()
        winner = self.gameLogic.getWinner()
        self.assertTrue(winner == 1)

    def test_moves4(self):
        playerPoints = [[3, 1], [3, 2], [3, 3]]
        cpuPoints =    [[2, 2], [2, 3]]
        self.addPlayerPoints(playerPoints)
        self.addCpuPoints(cpuPoints)
        XY = self.gameLogic.getNextCpuPoint()
        #print("Next Cpu point: {0}".format(XY))
        self.assertTrue(3 ==  XY[0])
        self.assertTrue(4 ==  XY[1])
        # self.gameLogic.printPoints()
        winner = self.gameLogic.getWinner()
        self.assertTrue(winner == 0)

    def test_moves5(self):
        playerPoints = [[3, 1], [3, 2], [3, 3]]
        cpuPoints =    [[2, 2], [2, 3]]
        self.addPlayerPoints(playerPoints)
        self.addCpuPoints(cpuPoints)
        XY = self.gameLogic.getNextCpuPoint()
        #print("Next Cpu point: {0}".format(XY))
        self.assertTrue(3 ==  XY[0])
        self.assertTrue(4 ==  XY[1])
        # self.gameLogic.printPoints()
        winner = self.gameLogic.getWinner()
        self.assertTrue(winner == 0)

    def test_moves6(self):
        playerPoints = [[4, 2], [4, 3], [4, 4]]
        cpuPoints =    [[2, 5], [3, 5]]
        self.addPlayerPoints(playerPoints)
        self.addCpuPoints(cpuPoints)
        XY = self.gameLogic.getNextCpuPoint()
        # print("Next Cpu point: {0}".format(XY))
        self.assertTrue(4 ==  XY[0])
        self.assertTrue(5 ==  XY[1])
        # self.gameLogic.printPoints()
        winner = self.gameLogic.getWinner()
        self.assertTrue(winner == 0)

    def test_moves7(self):
        playerPoints = [[3, 3], [4, 2], [6, 2], [7, 3], [8, 2]]
        cpuPoints =    [[3, 2], [4, 3], [6, 3], [7, 2]]
        self.addPlayerPoints(playerPoints)
        self.addCpuPoints(cpuPoints)
        XY = self.gameLogic.getNextCpuPoint()
        self.assertTrue(5 ==  XY[0])
        self.assertTrue(4 ==  XY[1])
        winner = self.gameLogic.getWinner()
        self.assertTrue(winner == 0)

    def test_moves8(self):
        playerPoints = [[3, 3], [4, 2], [6, 2], [8, 2]]
        cpuPoints =    [[3, 2], [4, 3], [6, 3]]
        self.addPlayerPoints(playerPoints)
        self.addCpuPoints(cpuPoints)
        XY = self.gameLogic.getNextCpuPoint()
        # print("Next Cpu point: {0}".format(XY))
        self.assertTrue(5 ==  XY[0])
        self.assertTrue(4 ==  XY[1])
        # self.gameLogic.printPoints()
        winner = self.gameLogic.getWinner()
        self.assertTrue(winner == 0)
 
unittest.main()
