import pygame, random
from pygame.locals import *

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)

pygame.init()
screen_max_x = 1280
screen_max_y = 1280
screen = pygame.display.set_mode((screen_max_x, screen_max_y))
clock = pygame.time.Clock()
pygame.display.set_caption("Sierpinski Triangle by Eero Viittala")
triangle = [(screen_max_x/2, 50), (50, screen_max_y-50), (screen_max_x-50, screen_max_y-50)]
triangleXY = [(screen_max_x/2, 51), (51, screen_max_y-50), (screen_max_x-51, screen_max_y-50)]
points = []
running = True

def area(x1, y1, x2, y2, x3, y3):
    return abs((x1 * (y2 - y3) + x2 * (y3 - y1)
                + x3 * (y1 - y2)) / 2.0)

def isPointInsideTriangle(x1, y1, x2, y2, x3, y3, x, y):
    A = area (x1, y1, x2, y2, x3, y3)
    A1 = area (x, y, x2, y2, x3, y3)
    A2 = area (x1, y1, x, y, x3, y3)
    A3 = area (x1, y1, x2, y2, x, y)

    return (A == A1 + A2 + A3)

def addPoints():
    x = 0
    y = 0
    if not points:
        isValid = False
        while not isValid:
            x = random.randrange(0, screen_max_x)
            y = random.randrange(0, screen_max_y)
            if isPointInsideTriangle(triangleXY[0][0], triangleXY[0][1],
                                    triangleXY[1][0], triangleXY[1][1],
                                    triangleXY[2][0], triangleXY[2][1],
                                    x, y):
                isValid = True;
        points.append((x, y))
    else:
        for i in range(10):
            lastPoint = points[-1]
            direction = random.randrange(0, 3)
            x = (lastPoint[0] + triangleXY[direction][0]) / 2 + 1
            y = (lastPoint[1] + triangleXY[direction][1]) / 2
            points.append((x, y))


while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    screen.fill(BLACK)
    pygame.draw.lines(screen, WHITE, True, triangle, 2)
    addPoints()
    for point in points:
        pygame.draw.circle(screen, WHITE, point, 1)
    pygame.display.flip()
    clock.tick(60)  # limits FPS to 60

pygame.quit()
